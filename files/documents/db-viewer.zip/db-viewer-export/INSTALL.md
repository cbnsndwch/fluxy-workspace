# DB Viewer — Installation Guide

A read/write SQLite browser for your Fluxy workspace. Browse tables, paginate rows, insert/edit/delete records — all in a clean split-panel UI.

---

## What's Included

```
backend/apps/db-viewer/index.ts          ← Express router (5 API endpoints)
frontend/components/DBViewer/DBViewerPage.tsx  ← React page component
```

No new dependencies required — uses `better-sqlite3` (already in every Fluxy workspace) and standard shadcn/ui components (`Button`, `Input`, `Dialog`).

---

## Step 1 — Copy the Files

```
backend/apps/db-viewer/index.ts
  → your-workspace/backend/apps/db-viewer/index.ts

frontend/components/DBViewer/DBViewerPage.tsx
  → your-workspace/client/src/components/DBViewer/DBViewerPage.tsx
```

---

## Step 2 — Register the Backend Router

Open `backend/index.ts`. Add the import near the top with the other router imports:

```typescript
import { createRouter as dbViewerRouter } from './apps/db-viewer/index.js';
```

Then mount it — the router takes the `db` instance (your `better-sqlite3` database). Add it with the other `app.use(...)` calls:

```typescript
app.use(dbViewerRouter(db));
```

> **How `db` is typically exported:** In a standard Fluxy backend, `db` comes from `./db.js`:
> ```typescript
> import { db } from './db.js';
> ```
> If your workspace uses a different variable name or import path, just pass whatever `better-sqlite3` instance you use.

---

## Step 3 — Add the Route

Open `client/src/router.tsx` (or wherever your React Router routes are defined).

Add the import at the top:

```typescript
import DBViewerPage, { loader as dbViewerLoader } from './components/DBViewer/DBViewerPage';
```

Add the route inside the authenticated children array (alongside your other page routes):

```typescript
{ path: 'db-viewer', children: [
    { index: true,          element: <DBViewerPage />, loader: dbViewerLoader },
    { path: ':tableName',   element: <DBViewerPage />, loader: dbViewerLoader },
]},
```

The nested `:tableName` route lets the selected table be reflected in the URL (bookmarkable, browser-back-friendly).

---

## Step 4 — Register the App

### If you use `appRegistry.ts`

If your workspace has a central app registry file (typically `client/src/lib/appRegistry.ts`), add an entry to the `APPS` array:

```typescript
import { Database } from 'lucide-react'; // add to imports at the top

// inside the APPS array:
{
    id: 'dbviewer',
    name: 'DB Viewer',
    description: 'Browse and manage SQLite tables',
    icon: Database,
    color: 'bg-emerald-500/10 text-emerald-500',
    path: '/db-viewer',
    section: 'workspace',   // or 'main' — wherever you want it grouped
},
```

This will automatically add it to the sidebar and dashboard if those components read from the registry.

### If you manage navigation manually

Add a sidebar link pointing to `/db-viewer` with whatever nav component your workspace uses. The page will render fine regardless — the registry entry is optional metadata.

---

## Step 5 — Verify

1. Save all files — the backend auto-restarts, Vite picks up the frontend changes.
2. Navigate to `/db-viewer` in your browser.
3. You should see a sidebar listing all tables in `app.db` with row counts.
4. Click a table to browse its rows. Click a row to edit it. Use **Add row** to insert.

---

## API Endpoints Added

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/db/tables` | List all tables with columns + row count |
| `GET` | `/api/db/:table/rows` | Paginated rows (`?page=0&limit=50`) |
| `POST` | `/api/db/:table/rows` | Insert a new row |
| `PUT` | `/api/db/:table/rows/:id` | Update a row by `id`; auto-sets `updated_at` if present |
| `DELETE` | `/api/db/:table/rows/:id` | Delete a row by `id` |

All endpoints use parameterized queries — no SQL injection surface.

> **Note on `id` column:** The edit/delete endpoints assume rows have an `id` column. Tables without one will list fine but the edit and delete buttons won't work correctly. This covers the vast majority of typical app tables.

---

## Notes on the Frontend Component

- Uses `useLoaderData` + React Router's `loader` function to pre-fetch the table list before render (no loading flash on initial paint).
- Pagination: 50 rows/page, max 200 via API.
- `created_at`, `updated_at`, and `id` columns are hidden from the edit form (auto-managed fields).
- Columns of type `NOT NULL` are marked "required" in the form — enforced by the database, not the frontend.
- The component uses `AppLayout` from `@/components/ui/app-layout` for the header chrome. If your workspace doesn't have this component, replace the outer `<AppLayout ...>` wrapper with a plain `<div>` — everything inside works independently.
