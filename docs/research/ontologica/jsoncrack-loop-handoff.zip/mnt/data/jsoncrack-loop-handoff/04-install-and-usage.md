# Install and Usage

## Files included

- `src/LoopAwareJsonCrack.tsx`, the loop-aware React component
- `src/LoopAwareJsonCrack.example.tsx`, example usage

## Dependencies

Install these in the target React app:

```bash
npm i react react-dom reaflow react-zoomable-ui
```

If the app already has `react` and `react-dom`, only add:

```bash
npm i reaflow react-zoomable-ui
```

## Drop-in usage

```tsx
import { LoopAwareJsonCrack } from "./src/LoopAwareJsonCrack";

export function Demo({ value }: { value: unknown }) {
  return <LoopAwareJsonCrack value={value} style={{ height: 720 }} />;
}
```

## Useful exports

### `LoopAwareJsonCrack`
Main renderer.

### `serializeWithRefs(value)`
Returns a JSON-like structure with `$ref` pointers.

### `buildLoopAwareGraph(value)`
Returns `{ nodes, edges, serialized, pointerToNodeId }`.

## Expected behavior

- first encounter of an object gets a canonical pointer ID
- repeated encounters become `$ref` in the serialized output
- repeated encounters become **back-reference edges** in the rendered graph
- self-references produce self-edges where the layout engine supports them

## Notes for integration agents

1. Use this component only for values that may contain cycles or shared references.
2. Keep the stock JSON Crack path for ordinary tree-shaped data if you want exact stock visuals.
3. Prefer `buildLoopAwareGraph()` for tests, since it gives you structured graph output without rendering.
4. If the host app already has its own pan / zoom shell, you can simplify the component and remove the `Space` wrapper.
