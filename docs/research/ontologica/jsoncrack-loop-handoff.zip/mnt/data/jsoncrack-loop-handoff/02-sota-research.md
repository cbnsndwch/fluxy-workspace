# SOTA Research

This section focuses on the current standards, platform capabilities, and library constraints that matter for this problem.

## 1. JSON itself does not support circular references

This is the root constraint. Native JSON has no object identity model, so `JSON.stringify()` throws on cyclic structures instead of inventing a reference scheme.

References:
- MDN, `JSON.stringify()` circular reference note: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
- MDN, cyclic object value error reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Errors/Cyclic_object_value

## 2. `structuredClone()` preserves cycles in memory, but it is not a portable wire format

Modern JS runtimes support `structuredClone()`, and it can preserve circular references. That is useful for cloning a live graph in memory, but it does not give us a stable, inspectable JSON representation for transport, debugging, or visualization interchange.

References:
- MDN, `structuredClone()` overview: https://developer.mozilla.org/en-US/docs/Web/API/Window/structuredClone
- MDN, structured clone algorithm, visited-reference map behavior: https://developer.mozilla.org/docs/Web/API/Web_Workers_API/Structured_clone_algorithm

## 3. OpenAPI and JSON Schema use `$ref` plus JSON Pointer / URI semantics

This is the strongest standards-aligned mental model for external references.

OpenAPI 3.1 and JSON Schema do not model runtime JS object identity directly, but they do define a clean, portable reference mechanism based on `$ref`, URIs, and JSON Pointer fragments. This is exactly the right inspiration for a serialized handoff format.

References:
- OpenAPI Specification 3.1, fragment handling and JSON Pointer semantics: https://spec.openapis.org/oas/v3.1.0.html
- Swagger docs on `$ref` and JSON Pointer examples: https://swagger.io/docs/specification/v3_0/using-ref/
- JSON Schema docs, recursive `$ref` support: https://json-schema.org/understanding-json-schema/structuring

## 4. Reviver-based reconstruction is real, but it is not the cleanest architecture here

`JSON.parse(..., reviver)` runs in depth-first order, beginning with the most nested properties. That makes it workable for certain transformations, but awkward for canonical path assignment, forward references, and UI-oriented graph reconstruction.

For this use case, a direct traversal over the live JS object graph or a dedicated second pass over parsed data is cleaner.

Reference:
- MDN, `JSON.parse()` reviver behavior: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse

## 5. The current `jsoncrack-react` package is tree-oriented at the public API level

The official docs expose a `json` prop and callbacks like `onParse`, but not a public API for injecting custom graph edges into the stock component.

The current source confirms that:
- the component owns `nodes` and `edges` internally
- parsing goes through a tree parser
- edges are derived from nested object and array structure, not semantic `$ref` interpretation

This means preprocessing alone cannot produce real loop edges in the stock renderer. To render true cycles, we must own the graph build step and pass an explicit graph to the rendering layer.

References:
- JSON Crack embed docs: https://jsoncrack.com/docs
- `jsoncrack-react` README: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/README.md
- component source: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/src/JSONCrackComponent.tsx
- parser source: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/src/parser.ts

## 6. The actual rendering stack is reusable

The current package source shows that JSON Crack uses `reaflow` and `react-zoomable-ui` under the hood. That makes it practical to build a loop-aware replacement component that preserves the same interaction model while swapping in a graph builder that understands identity and back-references.

Reference:
- current component source imports and rendering stack: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/src/JSONCrackComponent.tsx

## Bottom line

The best current approach is:

1. Traverse the live JS graph directly.
2. Assign canonical JSON Pointer IDs on first visit.
3. Serialize repeated references as `$ref` values.
4. Render nodes and edges from an explicit graph model.
5. Do not expect stock JSON Crack preprocessing alone to render reference edges.
