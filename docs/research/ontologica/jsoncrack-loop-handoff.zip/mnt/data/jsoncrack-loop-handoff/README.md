# JSON Crack Loop-Aware Handoff Pack

This package is meant to be given directly to a coding agent.

## Recommended reading order

1. `00-problem-description.md`
2. `01-what-we-considered-and-tried.md`
3. `02-sota-research.md`
4. `03-decision-we-made.md`
5. `04-install-and-usage.md`
6. `src/LoopAwareJsonCrack.tsx`
7. `src/LoopAwareJsonCrack.example.tsx`

## One-line summary

The stock JSON Crack component is tree-oriented. We needed real loop rendering for cyclic JS object graphs, so we built a loop-aware replacement that uses OpenAPI-style JSON Pointer refs for serialization and explicit graph edges for rendering.
