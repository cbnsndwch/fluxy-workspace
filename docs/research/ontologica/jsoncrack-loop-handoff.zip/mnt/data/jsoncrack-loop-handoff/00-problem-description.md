# Problem Description

## Goal

Make JSON Crack style visualization work for **live JavaScript object graphs that contain cycles and repeated references**.

The stock JSON Crack component is excellent for trees, nested objects, arrays, and normal JSON-like data. The gap is that it expects tree-shaped input and does not natively understand object identity, shared references, or self-references.

## What we needed

1. Accept a live JS value, not only pre-stringified JSON.
2. Handle self-references and repeated references without crashing or recursing forever.
3. Preserve a stable reference identity model.
4. Render **real graph edges** for back-references, not just leaf text like `"[Circular]"`.
5. Produce a serializable representation that a human or tool can inspect, ideally using an OpenAPI / JSON Schema style `$ref` convention.
6. Package the result as a drop-in component a coding agent can integrate into an existing React app.

## Non-goals

- Reproducing JSON Crack's internal visuals pixel-for-pixel.
- Supporting arbitrary JSON Schema `$dynamicRef` or full schema evaluation semantics.
- Solving persistence, hydration, or server transport for every JS runtime type.

## Practical acceptance criteria

- A cyclic object like `a.self = a` renders without crashing.
- Shared references like `a.owner = user` and `a.editor = user` produce edges to the same node.
- The same graph can be serialized to a JSON-like structure using canonical pointer IDs.
- Clicking a back-reference edge recenters the target node.
