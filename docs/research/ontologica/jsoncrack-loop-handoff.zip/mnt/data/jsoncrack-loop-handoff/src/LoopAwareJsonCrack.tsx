import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { Space, type ViewPort } from "react-zoomable-ui";
import { Canvas, Edge, Node as ReaflowNode, type EdgeProps, type ElkRoot, type NodeProps } from "reaflow";

export type LayoutDirection = "LEFT" | "RIGHT" | "DOWN" | "UP";
export type CanvasThemeMode = "light" | "dark";

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export type JsonObject = { [key: string]: JsonValue };

const SKIP = Symbol("skip");
const ROW_HEIGHT = 22;
const POINTER_FOOTER_HEIGHT = 18;
const NODE_HORIZONTAL_PADDING = 14;
const NODE_VERTICAL_PADDING = 10;
const MAX_NODE_WIDTH = 720;

const layoutOptions = {
  "elk.layered.compaction.postCompaction.strategy": "EDGE_LENGTH",
  "elk.layered.nodePlacement.strategy": "NETWORK_SIMPLEX",
  "elk.spacing.edgeLabel": "15",
} as const;

export interface LoopGraphRow {
  key: string | null;
  kind: "string" | "number" | "boolean" | "null" | "object" | "array" | "ref";
  value: string | number | boolean | null;
  childrenCount?: number;
  pointer?: string;
}

export interface LoopGraphNodeData {
  id: string;
  pointer: string;
  kind: "object" | "array" | "value";
  rows: LoopGraphRow[];
  width: number;
  height: number;
}

export interface LoopGraphEdgeData {
  id: string;
  from: string;
  to: string;
  text: string | null;
  isBackReference: boolean;
}

export interface LoopGraphBuildResult {
  nodes: LoopGraphNodeData[];
  edges: LoopGraphEdgeData[];
  serialized: JsonValue;
  pointerToNodeId: Map<string, string>;
}

export interface SerializeWithRefsOptions {
  refKey?: string;
}

export interface LoopAwareJsonCrackProps {
  value: unknown;
  theme?: CanvasThemeMode;
  layoutDirection?: LayoutDirection;
  className?: string;
  style?: CSSProperties;
  maxRenderableNodes?: number;
  renderNodeLimitExceeded?: (nodeCount: number, maxRenderableNodes: number) => ReactNode;
  onNodeClick?: (node: LoopGraphNodeData) => void;
  onGraphChange?: (graph: LoopGraphBuildResult) => void;
}

export interface LoopAwareJsonCrackRef {
  zoomIn: () => void;
  zoomOut: () => void;
  setZoom: (zoomFactor: number) => void;
  centerView: () => void;
}

type CompositeValue = object;

type SeenEntry = {
  pointer: string;
  nodeId: string;
  serialized: JsonObject | JsonValue[];
};

type QueryRoot = {
  querySelector: (selector: string) => Element | null;
};

function escapeJsonPointerSegment(segment: string): string {
  return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}

function joinPointer(base: string, segment: string): string {
  return base === "#" ? `#/${escapeJsonPointerSegment(segment)}` : `${base}/${escapeJsonPointerSegment(segment)}`;
}

function isDate(value: unknown): value is Date {
  return value instanceof Date;
}

function isMap(value: unknown): value is Map<unknown, unknown> {
  return value instanceof Map;
}

function isSet(value: unknown): value is Set<unknown> {
  return value instanceof Set;
}

function isComposite(value: unknown): value is CompositeValue {
  return typeof value === "object" && value !== null && !isDate(value);
}

function getCompositeKind(value: CompositeValue): "object" | "array" {
  if (Array.isArray(value) || isSet(value)) return "array";
  return "object";
}

function getChildrenCount(value: CompositeValue): number {
  if (Array.isArray(value)) return value.length;
  if (isSet(value)) return value.size;
  if (isMap(value)) return value.size;
  return Object.keys(value as Record<string, unknown>).length;
}

function getObjectEntries(value: CompositeValue): Array<[string, unknown]> {
  if (isMap(value)) {
    return Array.from(value.entries()).map(([key, child]) => [String(key), child]);
  }

  return Object.entries(value as Record<string, unknown>);
}

function getArrayItems(value: CompositeValue): unknown[] {
  if (Array.isArray(value)) return value;
  if (isSet(value)) return Array.from(value.values());
  return [];
}

function formatPrimitiveForDisplay(value: JsonPrimitive): string {
  if (value === null) return "null";
  if (typeof value === "string") return JSON.stringify(value);
  return String(value);
}

function summarizeComposite(kind: "object" | "array", count: number): string {
  return kind === "object" ? `{${count} keys}` : `[${count} items]`;
}

function coerceScalar(
  value: unknown,
  context: "object" | "array" | "root"
): JsonPrimitive | typeof SKIP | CompositeValue {
  if (value === null) return null;

  if (isDate(value)) {
    return Number.isNaN(value.valueOf()) ? "Invalid Date" : value.toISOString();
  }

  switch (typeof value) {
    case "string":
      return value;
    case "number":
      return Number.isFinite(value) ? value : String(value);
    case "boolean":
      return value;
    case "bigint":
      return value.toString();
    case "undefined":
    case "function":
    case "symbol":
      return context === "array" ? null : SKIP;
    case "object":
      return value as CompositeValue;
    default:
      return String(value);
  }
}

function estimateNodeSize(rows: LoopGraphRow[], pointer: string): Pick<LoopGraphNodeData, "width" | "height"> {
  const lines = rows.map(row => {
    const key = row.key === null ? "" : `${row.key}: `;
    const value =
      row.kind === "object"
        ? summarizeComposite("object", row.childrenCount ?? 0)
        : row.kind === "array"
          ? summarizeComposite("array", row.childrenCount ?? 0)
          : row.kind === "ref"
            ? `↩ ${row.pointer ?? row.value ?? "#"}`
            : formatPrimitiveForDisplay(row.value as JsonPrimitive);

    return `${key}${value}`;
  });

  const pointerLine = `@ ${pointer}`;
  const longest = Math.max(pointerLine.length, ...lines.map(line => line.length), 6);

  return {
    width: Math.min(MAX_NODE_WIDTH, Math.max(180, longest * 7.4 + NODE_HORIZONTAL_PADDING * 2)),
    height:
      NODE_VERTICAL_PADDING * 2 + rows.length * ROW_HEIGHT + POINTER_FOOTER_HEIGHT,
  };
}

function primitiveKind(value: JsonPrimitive): LoopGraphRow["kind"] {
  if (value === null) return "null";
  return typeof value as Exclude<LoopGraphRow["kind"], "object" | "array" | "ref" | "null">;
}

export function buildLoopAwareGraph(
  rootValue: unknown,
  options: SerializeWithRefsOptions = {}
): LoopGraphBuildResult {
  const refKey = options.refKey ?? "$ref";
  const seen = new WeakMap<object, SeenEntry>();
  const nodes: LoopGraphNodeData[] = [];
  const edges: LoopGraphEdgeData[] = [];
  const pointerToNodeId = new Map<string, string>();
  let nextNodeId = 1;
  let nextEdgeId = 1;

  function addEdge(from: string, to: string, text: string | null, isBackReference: boolean): void {
    edges.push({
      id: String(nextEdgeId++),
      from,
      to,
      text,
      isBackReference,
    });
  }

  function visitComposite(value: CompositeValue, pointer: string): SeenEntry {
    const existing = seen.get(value as object);
    if (existing) return existing;

    const kind = getCompositeKind(value);
    const nodeId = String(nextNodeId++);
    const serialized: JsonObject | JsonValue[] = kind === "array" ? [] : {};
    const entry: SeenEntry = {
      pointer,
      nodeId,
      serialized,
    };

    seen.set(value as object, entry);
    pointerToNodeId.set(pointer, nodeId);

    const rows: LoopGraphRow[] = [];

    if (kind === "array") {
      const items = getArrayItems(value);

      items.forEach((item, index) => {
        const key = String(index);
        const childPointer = joinPointer(pointer, key);
        const coerced = coerceScalar(item, "array");

        if (coerced === SKIP) {
          (serialized as JsonValue[]).push(null);
          rows.push({ key, kind: "null", value: null });
          return;
        }

        if (isComposite(coerced)) {
          const prior = seen.get(coerced as object);
          if (prior) {
            (serialized as JsonValue[]).push({ [refKey]: prior.pointer } as JsonObject);
            rows.push({
              key,
              kind: "ref",
              value: prior.pointer,
              pointer: prior.pointer,
              childrenCount: getChildrenCount(coerced),
            });
            addEdge(nodeId, prior.nodeId, key, true);
            return;
          }

          const child = visitComposite(coerced, childPointer);
          (serialized as JsonValue[]).push(child.serialized as JsonValue);
          rows.push({
            key,
            kind: getCompositeKind(coerced),
            value: summarizeComposite(getCompositeKind(coerced), getChildrenCount(coerced)),
            childrenCount: getChildrenCount(coerced),
            pointer: child.pointer,
          });
          addEdge(nodeId, child.nodeId, key, false);
          return;
        }

        (serialized as JsonValue[]).push(coerced as JsonValue);
        rows.push({
          key,
          kind: primitiveKind(coerced as JsonPrimitive),
          value: coerced as JsonPrimitive,
        });
      });
    } else {
      const entries = getObjectEntries(value);

      entries.forEach(([key, childValue]) => {
        const childPointer = joinPointer(pointer, key);
        const coerced = coerceScalar(childValue, "object");

        if (coerced === SKIP) {
          return;
        }

        if (isComposite(coerced)) {
          const prior = seen.get(coerced as object);
          if (prior) {
            (serialized as JsonObject)[key] = { [refKey]: prior.pointer } as JsonValue;
            rows.push({
              key,
              kind: "ref",
              value: prior.pointer,
              pointer: prior.pointer,
              childrenCount: getChildrenCount(coerced),
            });
            addEdge(nodeId, prior.nodeId, key, true);
            return;
          }

          const child = visitComposite(coerced, childPointer);
          (serialized as JsonObject)[key] = child.serialized as JsonValue;
          rows.push({
            key,
            kind: getCompositeKind(coerced),
            value: summarizeComposite(getCompositeKind(coerced), getChildrenCount(coerced)),
            childrenCount: getChildrenCount(coerced),
            pointer: child.pointer,
          });
          addEdge(nodeId, child.nodeId, key, false);
          return;
        }

        (serialized as JsonObject)[key] = coerced as JsonValue;
        rows.push({
          key,
          kind: primitiveKind(coerced as JsonPrimitive),
          value: coerced as JsonPrimitive,
        });
      });
    }

    if (rows.length === 0) {
      rows.push({
        key: null,
        kind,
        value: summarizeComposite(kind, 0),
        childrenCount: 0,
      });
    }

    const { width, height } = estimateNodeSize(rows, pointer);
    nodes.push({
      id: nodeId,
      pointer,
      kind,
      rows,
      width,
      height,
    });

    return entry;
  }

  const coercedRoot = coerceScalar(rootValue, "root");

  if (coercedRoot === SKIP) {
    const rows: LoopGraphRow[] = [{ key: null, kind: "null", value: null }];
    const { width, height } = estimateNodeSize(rows, "#");
    nodes.push({ id: "1", pointer: "#", kind: "value", rows, width, height });
    pointerToNodeId.set("#", "1");
    return {
      nodes,
      edges,
      serialized: null,
      pointerToNodeId,
    };
  }

  if (isComposite(coercedRoot)) {
    const root = visitComposite(coercedRoot, "#");
    return {
      nodes,
      edges,
      serialized: root.serialized as JsonValue,
      pointerToNodeId,
    };
  }

  const rows: LoopGraphRow[] = [
    {
      key: null,
      kind: primitiveKind(coercedRoot as JsonPrimitive),
      value: coercedRoot as JsonPrimitive,
    },
  ];
  const { width, height } = estimateNodeSize(rows, "#");
  nodes.push({ id: "1", pointer: "#", kind: "value", rows, width, height });
  pointerToNodeId.set("#", "1");

  return {
    nodes,
    edges,
    serialized: coercedRoot as JsonValue,
    pointerToNodeId,
  };
}

export function serializeWithRefs(value: unknown, options?: SerializeWithRefsOptions): JsonValue {
  return buildLoopAwareGraph(value, options).serialized;
}

function getThemeVars(theme: CanvasThemeMode): CSSProperties {
  if (theme === "light") {
    return {
      "--loop-bg": "#ffffff",
      "--loop-node-fill": "#ffffff",
      "--loop-node-stroke": "#d1d5db",
      "--loop-text": "#111827",
      "--loop-key": "#6b7280",
      "--loop-string": "#047857",
      "--loop-number": "#1d4ed8",
      "--loop-boolean": "#b45309",
      "--loop-null": "#6b7280",
      "--loop-ref": "#7c3aed",
      "--loop-edge": "#9ca3af",
      "--loop-edge-ref": "#7c3aed",
      "--loop-pointer": "#9ca3af",
      "--loop-overlay": "rgba(255,255,255,0.8)",
    } as CSSProperties;
  }

  return {
    "--loop-bg": "#0b1020",
    "--loop-node-fill": "#111827",
    "--loop-node-stroke": "#374151",
    "--loop-text": "#f3f4f6",
    "--loop-key": "#9ca3af",
    "--loop-string": "#34d399",
    "--loop-number": "#60a5fa",
    "--loop-boolean": "#f59e0b",
    "--loop-null": "#9ca3af",
    "--loop-ref": "#a78bfa",
    "--loop-edge": "#4b5563",
    "--loop-edge-ref": "#a78bfa",
    "--loop-pointer": "#6b7280",
    "--loop-overlay": "rgba(11,16,32,0.8)",
  } as CSSProperties;
}

function rowValueColor(kind: LoopGraphRow["kind"]): string {
  switch (kind) {
    case "string":
      return "var(--loop-string)";
    case "number":
      return "var(--loop-number)";
    case "boolean":
      return "var(--loop-boolean)";
    case "null":
      return "var(--loop-null)";
    case "ref":
      return "var(--loop-ref)";
    default:
      return "var(--loop-text)";
  }
}

function displayRowValue(row: LoopGraphRow): string {
  if (row.kind === "object") return summarizeComposite("object", row.childrenCount ?? 0);
  if (row.kind === "array") return summarizeComposite("array", row.childrenCount ?? 0);
  if (row.kind === "ref") return `↩ ${row.pointer ?? row.value ?? "#"}`;
  return formatPrimitiveForDisplay(row.value as JsonPrimitive);
}

function LoopNode({ properties, onNodeClick, ...nodeProps }: NodeProps<LoopGraphNodeData> & {
  onNodeClick?: (node: LoopGraphNodeData) => void;
}) {
  const data = properties;

  return (
    <ReaflowNode
      {...nodeProps}
      animated={false}
      label={null as any}
      onClick={(_event: React.MouseEvent<SVGGElement>, node: LoopGraphNodeData) => onNodeClick?.(node)}
      style={{
        fill: "var(--loop-node-fill)",
        stroke: "var(--loop-node-stroke)",
        strokeWidth: 1,
      }}
    >
      {() => (
        <foreignObject width={data.width} height={data.height} x={0} y={0}>
          <div
            data-id={`node-${data.id}`}
            style={{
              boxSizing: "border-box",
              width: data.width,
              height: data.height,
              padding: `${NODE_VERTICAL_PADDING}px ${NODE_HORIZONTAL_PADDING}px`,
              fontFamily:
                "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, monospace",
              fontSize: 12,
              lineHeight: `${ROW_HEIGHT}px`,
              color: "var(--loop-text)",
              background: "transparent",
              overflow: "hidden",
            }}
          >
            {data.rows.map((row, index) => (
              <div
                key={`${data.id}:${index}`}
                style={{
                  display: "flex",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  height: ROW_HEIGHT,
                }}
                title={`${row.key === null ? "" : `${row.key}: `}${displayRowValue(row)}`}
              >
                {row.key !== null && (
                  <span style={{ color: "var(--loop-key)", flexShrink: 0 }}>{row.key}:&nbsp;</span>
                )}
                <span
                  style={{
                    color: rowValueColor(row.kind),
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  {displayRowValue(row)}
                </span>
              </div>
            ))}
            <div
              style={{
                marginTop: 2,
                color: "var(--loop-pointer)",
                fontSize: 11,
                lineHeight: `${POINTER_FOOTER_HEIGHT - 2}px`,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
              title={data.pointer}
            >
              @{data.pointer}
            </div>
          </div>
        </foreignObject>
      )}
    </ReaflowNode>
  );
}

function isQueryRoot(value: unknown): value is QueryRoot {
  return (
    typeof value === "object" &&
    value !== null &&
    "querySelector" in value &&
    typeof (value as QueryRoot).querySelector === "function"
  );
}

function LoopEdge({
  properties,
  viewPort,
  hostElement,
  ...edgeProps
}: EdgeProps<LoopGraphEdgeData> & {
  viewPort: ViewPort | null;
  hostElement: QueryRoot | null;
}) {
  const [hovered, setHovered] = useState(false);
  const edge = properties;

  const handleClick = useCallback(() => {
    const queryRoot = isQueryRoot(hostElement)
      ? hostElement
      : typeof document !== "undefined"
        ? document
        : null;

    if (!queryRoot) return;

    const targetNodeDom = queryRoot.querySelector(`[data-id="node-${edge.to}"]`) as HTMLElement | null;
    if (!targetNodeDom?.parentElement) return;

    viewPort?.camera.centerFitElementIntoView(targetNodeDom.parentElement, {
      elementExtraMarginForZoom: 120,
    });
  }, [edge.to, hostElement, viewPort]);

  return (
    <Edge
      {...edgeProps}
      onClick={handleClick}
      onEnter={() => setHovered(true)}
      onLeave={() => setHovered(false)}
      style={{
        stroke: edge.isBackReference ? "var(--loop-edge-ref)" : "var(--loop-edge)",
        strokeWidth: hovered ? 2.25 : 1.5,
        strokeDasharray: edge.isBackReference ? "6 4" : undefined,
      }}
    />
  );
}

export const LoopAwareJsonCrack = forwardRef<LoopAwareJsonCrackRef, LoopAwareJsonCrackProps>(
  (
    {
      value,
      theme = "dark",
      layoutDirection = "RIGHT",
      className,
      style,
      maxRenderableNodes = 1500,
      renderNodeLimitExceeded,
      onNodeClick,
      onGraphChange,
    },
    ref
  ) => {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const [viewPort, setViewPort] = useState<ViewPort | null>(null);
    const [paneWidth, setPaneWidth] = useState(2000);
    const [paneHeight, setPaneHeight] = useState(2000);

    const graph = useMemo(() => buildLoopAwareGraph(value), [value]);
    const overLimit = graph.nodes.length > maxRenderableNodes;

    useEffect(() => {
      onGraphChange?.(graph);
    }, [graph, onGraphChange]);

    useEffect(() => {
      if (!viewPort) return;
      const container = containerRef.current;
      if (!container || typeof ResizeObserver === "undefined") return;

      const observer = new ResizeObserver(() => {
        viewPort.updateContainerSize();
      });

      observer.observe(container);
      return () => observer.disconnect();
    }, [viewPort]);

    const fitToContainer = useCallback(() => {
      if (!viewPort || !containerRef.current) return;
      const graphPane = containerRef.current.querySelector("svg") as SVGSVGElement | null;
      if (!graphPane) return;
      viewPort.camera.centerFitElementIntoView(graphPane, {
        elementExtraMarginForZoom: 80,
      });
    }, [viewPort]);

    useImperativeHandle(
      ref,
      () => ({
        zoomIn: () => viewPort?.camera.recenter(viewPort.centerX, viewPort.centerY, viewPort.zoomFactor + 0.1),
        zoomOut: () => viewPort?.camera.recenter(viewPort.centerX, viewPort.centerY, viewPort.zoomFactor - 0.1),
        setZoom: (zoomFactor: number) => viewPort?.camera.recenter(viewPort.centerX, viewPort.centerY, zoomFactor),
        centerView: fitToContainer,
      }),
      [fitToContainer, viewPort]
    );

    const renderNode = useCallback(
      (nodeProps: NodeProps<LoopGraphNodeData>) => (
        <LoopNode {...nodeProps} onNodeClick={onNodeClick} />
      ),
      [onNodeClick]
    );

    const renderEdge = useCallback(
      (edgeProps: EdgeProps<LoopGraphEdgeData>) => (
        <LoopEdge {...edgeProps} viewPort={viewPort} hostElement={containerRef.current} />
      ),
      [viewPort]
    );

    const handleLayoutChange = useCallback((layout: ElkRoot) => {
      if (!layout.width || !layout.height) return;

      const container = containerRef.current;
      const minWidth = container?.clientWidth ?? 0;
      const minHeight = container?.clientHeight ?? 0;

      setPaneWidth(Math.max(minWidth, layout.width + 80));
      setPaneHeight(Math.max(minHeight, layout.height + 80));

      requestAnimationFrame(() => {
        fitToContainer();
      });
    }, [fitToContainer]);

    const combinedStyle: CSSProperties = {
      position: "relative",
      width: "100%",
      height: 700,
      overflow: "hidden",
      background: "var(--loop-bg)",
      borderRadius: 12,
      ...getThemeVars(theme),
      ...style,
    };

    return (
      <div ref={containerRef} className={className} style={combinedStyle}>
        {overLimit &&
          (renderNodeLimitExceeded ? (
            renderNodeLimitExceeded(graph.nodes.length, maxRenderableNodes)
          ) : (
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "grid",
                placeItems: "center",
                background: "var(--loop-overlay)",
                color: "var(--loop-text)",
                fontFamily: "system-ui, sans-serif",
                zIndex: 5,
                padding: 24,
                textAlign: "center",
              }}
            >
              This graph has {graph.nodes.length} nodes and exceeds the configured limit of {maxRenderableNodes}.
            </div>
          ))}

        {!overLimit && (
          <>
            <button
              type="button"
              onClick={fitToContainer}
              style={{
                position: "absolute",
                top: 12,
                right: 12,
                zIndex: 5,
                border: 0,
                borderRadius: 999,
                padding: "8px 12px",
                fontSize: 12,
                cursor: "pointer",
                background: "var(--loop-node-fill)",
                color: "var(--loop-text)",
                boxShadow: "0 1px 2px rgba(0,0,0,0.2)",
              }}
            >
              Center
            </button>

            <Space
              onCreate={setViewPort}
              treatTwoFingerTrackPadGesturesLikeTouch
              style={{ width: "100%", height: "100%" }}
            >
              <Canvas
                nodes={graph.nodes}
                edges={graph.edges}
                node={renderNode}
                edge={renderEdge}
                direction={layoutDirection}
                layoutOptions={layoutOptions}
                width={paneWidth}
                height={paneHeight}
                maxWidth={paneWidth}
                maxHeight={paneHeight}
                pannable={false}
                zoomable={false}
                readonly
                dragNode={null}
                dragEdge={null}
                animated={false}
                defaultPosition={null as unknown as undefined}
                arrow={null}
                onLayoutChange={handleLayoutChange}
              />
            </Space>
          </>
        )}
      </div>
    );
  }
);

LoopAwareJsonCrack.displayName = "LoopAwareJsonCrack";
