import React, { useMemo } from "react";
import { LoopAwareJsonCrack, serializeWithRefs } from "./LoopAwareJsonCrack";

export default function Example() {
  const value = useMemo(() => {
    const company: any = { name: "Acme Veterinary & Boarding" };
    const owner: any = { id: 1, name: "Maya", company };
    const booking: any = {
      id: "bk_123",
      customer: owner,
      pets: [{ id: "pet_1", name: "Luna" }],
    };

    company.owner = owner;
    company.latestBooking = booking;
    owner.latestBooking = booking;
    booking.company = company;
    booking.self = booking;

    return company;
  }, []);

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <LoopAwareJsonCrack
        value={value}
        theme="dark"
        style={{ height: 720 }}
        onGraphChange={graph => {
          console.log("serialized with refs", graph.serialized);
        }}
      />

      <pre
        style={{
          margin: 0,
          padding: 16,
          borderRadius: 12,
          overflow: "auto",
          background: "#0b1020",
          color: "#f3f4f6",
        }}
      >
        {JSON.stringify(serializeWithRefs(value), null, 2)}
      </pre>
    </div>
  );
}
