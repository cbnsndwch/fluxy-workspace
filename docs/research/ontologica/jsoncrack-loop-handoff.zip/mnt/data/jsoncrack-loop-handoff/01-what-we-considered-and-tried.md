# What We Considered and Tried

## 1. Use the stock `jsoncrack-react` component as-is

### Idea
Pass the live value directly to `JSONCrack`, or stringify it first.

### Why it failed
Plain JSON does not support object references, so cyclic inputs fail with `JSON.stringify()` semantics.

Reference:
- MDN, `JSON.stringify()` circular reference behavior: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
- MDN, cyclic object value error: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Errors/Cyclic_object_value

## 2. Serialize cycles into `$ref` objects, then feed that into stock JSON Crack

### Idea
Convert this:

```ts
booking.company = company;
company.latestBooking = booking;
```

into something like this:

```json
{
  "latestBooking": {
    "$ref": "#/bookings/0"
  }
}
```

### Why it was not enough
This gives us a readable serialized form, but the stock parser still sees a normal JSON tree. It creates edges only from nested object and array structure, not from semantic `$ref` links. So `$ref` shows up as ordinary data, not as a graph edge.

Evidence from the current package and source:
- Public `jsoncrack-react` docs: https://jsoncrack.com/docs
- Package README with public props: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/README.md
- Current component source, it owns `nodes` and `edges` internally: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/src/JSONCrackComponent.tsx
- Current parser source, edges are generated from nested `object` and `array` structure during traversal: https://github.com/AykutSarac/jsoncrack.com/blob/main/packages/jsoncrack-react/src/parser.ts

## 3. Use a `JSON.parse(..., reviver)` approach to rebuild references by path

### Idea
Store path IDs, then resolve them during parse with a reviver.

### Why we did not choose it
This is possible in narrow cases, but it is a poor primary mechanism here.

Reasons:
- `JSON.parse` reviver runs depth-first, from nested values upward, which makes stable full-path identity tracking awkward.
- Forward references and aliasing are cleaner with a custom traversal pass.
- Even if reviver reconstruction worked, stock JSON Crack still would not treat `$ref` as an edge.

Reference:
- MDN, `JSON.parse()` reviver order: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse

## 4. Use a circular JSON library like `flatted`

### Idea
Let an existing format encode and decode cycles.

### Why we did not choose it
This solves encoding and decoding, but it still does not solve the actual UI requirement. JSON Crack would still need custom graph semantics for back-reference edges. Also, `flatted` uses its own compact format, which is less intuitive than JSON Pointer style references for debugging and agent handoff.

References:
- npm search shows `flatted` as a common circular JSON package: https://www.npmjs.com/browse/keyword/circular
- `circular-json` is deprecated and explicitly points to `flatted` as successor: https://www.npmjs.com/package/circular-json

## 5. Own the graph layer while keeping the JSON Crack mental model

### Idea
Traverse the live object graph ourselves, assign canonical JSON Pointer IDs, serialize repeated references as `$ref`, and render graph nodes and back-reference edges using the same underlying graph primitives that JSON Crack itself uses.

### Why this won
It solves the real problem, not just the serialization problem.

- Cycles are preserved.
- Shared references point to the same target node.
- `$ref` remains available as a portable serialized representation.
- Rendering reflects semantic references, not only tree nesting.
