# Decision We Made

## Decision

We built a **loop-aware replacement component** instead of trying to force the stock JSON Crack component to understand `$ref` semantics.

## The decision in one sentence

Use OpenAPI-style JSON Pointer references for serialization, but own the graph-building and rendering layer so repeated references become **real edges** in the UI.

## Why this is the right decision

### 1. It solves the actual product problem
The requirement was not only to serialize cycles, it was to **render** them.

### 2. It keeps the serialized form legible
The generated structure uses canonical pointers like `#/owner/latestBooking`, which are easy for humans and agents to inspect.

### 3. It aligns with standards without pretending JSON has identity semantics
We borrow the `$ref` / JSON Pointer model from OpenAPI and JSON Schema, but we do not pretend the stock tree parser can infer graph edges from that alone.

### 4. It avoids brittle reviver magic
Instead of trying to reconstruct identity indirectly through parser callback order, we traverse the live graph directly and preserve identity with a `WeakMap`.

### 5. It is integration-friendly
The resulting component is a normal React component. A coding agent can drop it into an existing app, point it at a live JS object, and move on.

## Tradeoffs we accepted

- We are not using the stock `JSONCrack` component directly for the loop-aware path.
- This is a small custom graph component, not a one-line wrapper.
- Exact stock visual parity was traded for correctness and maintainability.

## Tradeoffs we rejected

- Leaf-only `"[Circular]"` rendering, because it loses graph semantics.
- Using a compact circular JSON library format as the primary interchange format, because pointer-based refs are easier to debug and explain.
- Hidden reviver tricks that make future maintenance harder.
